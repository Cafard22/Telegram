import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from core.settings.config import bot_token
from core.handlers.basic import get_start, get_exception
from core.handlers.start import start_bot, stop_bot
from core.handlers.random import random_number
from core.handlers.answer_how import get_answer_how
from core.handlers.conversion import document_conversion, audio_conversion


async def start():
    logging.basicConfig(level=logging.INFO)
    bot = Bot(token=bot_token, parse_mode='HTML')
    dp = Dispatcher()

    dp.startup.register(start_bot)
    dp.shutdown.register(stop_bot)

    dp.message.register(get_start, Command(commands=['start']))
    dp.message.register(random_number, F.text.lower() == 'рандомное число')
    dp.message.register(get_answer_how, F.text.lower() == 'как дела?')
    dp.message.register(document_conversion, F.document)
    dp.message.register(audio_conversion, F.audio)

    # exception
    dp.message.register(get_exception)

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == '__main__':
    asyncio.run(start())

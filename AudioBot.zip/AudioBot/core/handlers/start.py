from aiogram import Bot
from core.settings.config import admin_id


async def start_bot(bot: Bot):
    try:
        await bot.send_message(admin_id, 'Бот запущен')
    except:
        print("Отправить сообщение не удалось, проверьте параметр ADMIN_ID")


async def stop_bot(bot: Bot):
    try:
        await bot.send_message(admin_id, 'Бот остановлен')
    except:
        print("Отправить сообщение не удалось, проверьте параметр ADMIN_ID")

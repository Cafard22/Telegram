from aiogram.types import Message
from aiogram import Bot
from core.modules.converter import wav_to_text


async def document_conversion(message: Message, bot: Bot):
    if message.document.file_name[-3:] == "wav":
        file_id = message.document.file_id
        file = await bot.get_file(file_id)
        file_path = file.file_path
        await bot.download_file(file_path, f"src/{file_id}.wav")
        await message.answer(f"Получен документ! Начинаю получать текст")
        answer = wav_to_text(file_id)
        await bot.send_message(message.chat.id, f"Результат:\n\n{answer}")
    else:
        await message.answer(f"Бот принимает только аудио формата wav")


async def audio_conversion(message: Message, bot: Bot):
    if message.audio.file_name[-3:] == "wav":
        file_id = message.audio.file_id
        file = await bot.get_file(file_id)
        file_path = file.file_path
        await bot.download_file(file_path, f"src/{file_id}.wav")
        await message.answer(f"Получено аудио! Начинаю получать текст")
        answer = wav_to_text(file_id)
        await bot.send_message(message.chat.id, f"Результат:\n\n{answer}")
    else:
        await message.answer(f"Бот принимает только аудио формата wav")


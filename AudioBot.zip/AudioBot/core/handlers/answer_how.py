import random
from aiogram.types import Message
from core.keyboards.reply import get_reply_keyboard


async def get_answer_how(message: Message):
    answer_list = ["Всё отлично)",
                   "Замечательно",
                   "норм.",
                   "Бывало и лучше..",
                   "Ты спрашиваешь у бота, как у него дела.\nНе думал друзей себе найти?",
                   "Пип пип"]
    answer_number = random.choice(answer_list)
    await message.answer(answer_number, reply_markup=get_reply_keyboard())

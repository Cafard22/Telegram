from aiogram.types import Message
from core.keyboards.reply import get_reply_keyboard


async def get_start(message: Message):
    await message.answer(f"<b>И тебе привет!!</b>\n\n"
                         f"Я умею конвертировать голос из файла формата wav в текст:)", reply_markup=get_reply_keyboard())


async def get_exception(message: Message):
    await message.answer(f"Оу, я даже не знаю как ответить на такое🧐")
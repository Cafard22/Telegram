import random
from aiogram.types import Message
from core.keyboards.reply import get_reply_keyboard


async def random_number(message: Message):
    answer_number = random.randint(-100, 100)
    await message.answer(f"А вот и случайное число: <tg-spoiler>{answer_number}</tg-spoiler>",
                         reply_markup=get_reply_keyboard())

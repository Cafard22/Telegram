import speech_recognition as sr


r = sr.Recognizer()


def wav_to_text(file_id):
    with sr.AudioFile(f"src/{file_id}.wav") as source:
        audio_data = r.record(source)
        text = r.recognize_google(audio_data, language="ru_RU")
        return text
